#include "Deck.h"
#include <iostream>
#include <cstdlib>
#include <random>
#include <list>
#include <algorithm>

using std::cout;

//constructor that calls card set up automatically
Deck::Deck()
{
    SetUpCards();
    SetPlayerHand();
    InitializeTurnOrder(0);
}

//destructor to free allocated memory
Deck::~Deck()
{
    for (int i = 0; i < 52; i++)
    {
        delete arrCards[i];
    }
}

void Deck::SetUpCards()
{
    int index = 0; //tracks the position in the deck array
    
    //issue fix: in the For-Loop, cards index being declared with spades and run through all 13 different card types, meaning
    //that values between 1-13 where spades 3 - spades 2. We obviously don't want this as it makes checking the value
    //much harder in the game compared to seeing if the index of the value is greater than the index of the previous value
    
    //loop through card names from THREE to TWO
    for (int rows = (int)Rank::THREE; rows <= (int)Rank::TWO; rows++)
    {
        //loop through suits from SPADES to HEARTS
        for (int col = (int)Suits::SPADES; col <= (int)Suits::HEARTS; col++)
        {
            //allocates memory for new Card object
            Card* c = new Card; 
            
            //setting suit and card name depending on row and column
            c->suit = (Suits)col;
            c->name = (Rank)rows;
            
            //for card assigning, starting at 3 of spades
            c->value = (int)c->name;

            //set the play order index, which combines both suit and rank
            c->playOrderIndex = c->value * 4 - 3 + col;
            
            //assign the card to the correct position in the array
            arrCards[index] = c;
            
            index++;  //move to the next position in the deck
        }
    }
}

void Deck::SetPlayerHand()
{
    int min = 0,
        max = 51;
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(min, max);
    
    cards = AVLTree<int>();
    
    // loops the values 4 times 
    for (int playerIndex = 0; playerIndex < 4; playerIndex++)
    {
        playerHand[playerIndex] = AVLTree<int>(); // resets each players hand
        
        while (playerHand[playerIndex].size() < 13)
        {
            int randomCard = distrib(gen);
            
            if (!cards.search(randomCard))
            {
                // inserts the card into the overall deck, alongside the players hand
                cards.insert(randomCard);
                playerHand[playerIndex].insert(randomCard);
            }
        }
        // checks if the value inserted into the player hand is the starting value
        if (playerHand[playerIndex].search(0) == true)
        {
            InitializeTurnOrder(playerIndex);
        }
    }
}

void Deck::PrintHandHelper(AVLNode<int>* node, int& index) 
{
    if (!node) 
    {
        return;
    }
    
    // traverses the left subtree
    PrintHandHelper(node->left, index);

    // process the current node
    cout << index << ". ";
    arrCards[node->key]->PrintSuit();
    cout << " ";
    index++;

    // traverse the right subtree
    PrintHandHelper(node->right, index);
}

void Deck::PrintHand(AVLTree<int>& hand) 
{
    int index = 1;
    PrintHandHelper(hand.getRoot(), index); // assume `getRoot()` provides access to the root
    cout << std::endl;
}

void Deck::PrintRound()
{
    cout << "--- Round State ---" << std::endl;
    cout << "Cards played this round: \n";
    if (playedCount == 0) 
    {
        cout << "No cards played yet." << std::endl;
    } 
    else 
    {
        for (int i = 0; i < playedCount; i++) 
        {
            playedCards[i]->PrintSuit();
        }
        cout << std::endl;
    }
}

// prints out the value of the card
void Deck::PlayCard(int playerIndex, Card* card) 
{
    cout << "Player " << (playerIndex + 1) << " plays card: ";
    card->PrintSuit();
    
    // adds the card into the played cards array
    AddPlayedCard(card);

    // remove the card from the player's hand
    RemoveCard(playerHand[playerIndex], card->value);
}

// function removes the card from the player hand
void Deck::RemoveCard(AVLTree<int>& playerHand, int cardValue) 
{
    playerHand.remove(cardValue);
}

// function keeps track of all the cards played, also works if every single card is played in 1 round
void Deck::AddPlayedCard(Card* card) 
{
    if (playedCount < 52) 
    {
        playedCards[playedCount++] = card; // Add the card and increment count
    } 
    else 
    {
        cout << "Error: Played cards array is full!" << std::endl;
    }
}

void Deck::InitializeTurnOrder(int startingPlayer)
{
    while (!turn.empty())
    {
        turn.pop();
    }
    
    for (int i = 0; i < 4; i++) 
    {
        int playerIndex = (startingPlayer + i) % 4;
        turn.push(playerIndex);
    }
}

void Deck::GameLoop()
{
    // set the played count to 0 to reset the cards played per round
    playedCount = 0;
    
    // initializes starting variable when a new round starts
    bool newRound = false;
    
    // card used to keep track of the last played card
    int lastCardPlayed = 0;
    
    // list used to keep track of what cards were played for the round
    AVLTree<int> currentRoundCards;
    
    while (!turn.empty()) 
    {
        PrintRound();
        
        if (newRound) 
        {
            //resets the players at the start of every newRound and disables new round after
            ResetPlayers();
            newRound = false;
        }
        
        //gets the player that's at the front of the queue
        currentPlayer = turn.front();
        
        //remove the player front the queue
        turn.pop(); 
        
        //skips the turn if the player already passed for the round
        if (!activePlayers[currentPlayer]) 
        {
            continue;
        }
        
        cout << "Player " << currentPlayer + 1 << "'s turn" << std::endl;

        //process the player's turn, returns a true of false to see if they passed
        bool passed = PlayerTurn(currentPlayer, lastCardPlayed);

        if (!passed) 
        {
            cout << "Player " << currentPlayer + 1 << " passes their turn." << std::endl;
            activePlayers[currentPlayer] = false;
        }
        else 
        {
            //if the player doesn't pass, they go to the back of the queue for the next round
            turn.push(currentPlayer);
            
            currentRoundCards.insert(lastCardPlayed);
        }
        
        //checks if all players passed or played
        bool allPassed = true;
        for (int i = 0; i <= 3; i++)
        {
            if (activePlayers[i])
            {
                allPassed = false;  //all players passed, start a new round
                break;
            }
        }
        if (allPassed) //if all players passed, then new round starts
        {
            cout << "\n--- End Round State ---\n\n";
            newRound = true;
            cout << "New round has started. " << std::endl;

            //resets the turn order
            InitializeTurnOrder((currentPlayer + 1) % 4);
        }
    }
}

bool Deck::PlayerTurn(int playerIndex, int &lastPlayedCard)
{
    bool valid = false; // variable shows whether or not the input the player chooses is valid or not
    int choice = 0;         // stores the choice player will input
    
    // checks if the player skipped their turn
    if (!activePlayers[playerIndex]) 
    {
        return false;
    }
    
    // print the player's hand
    cout << "Player " << playerIndex + 1 << "'s hand: \n";
    PrintHand(playerHand[playerIndex]);

    // if the player has no cards left they win
    if (playerHand[playerIndex].size() == 0) 
    {
        cout << "Player " << (playerIndex + 1) << " wins the game!" << std::endl;
        return true;
    }

    cout << "Choose an action (1 for play, 2 for pass): ";
    std::cin >> choice;
    // loop the function while the input is not valid
    while (!valid)
    {
        if (choice == 1) 
        {
            valid = true;

            // let the player choose a card to play
            int cardChoice;
            cout << "Choose a valid card to play (enter card index from hand): ";
            std::cin >> cardChoice;
            
            Card* selectedCard = GetCardFromIndex(playerHand[playerIndex], cardChoice);
            
            //checks to see if the card index is valid   

            if (selectedCard) 
            {
                PlayCard(playerIndex, selectedCard);
                // else the card is not a valid play and recursively call the function again
            }
            else 
            {
                cout << "Card " << cardChoice << " is not a valid play. Try again.\n" << std::endl;
                PlayerTurn(playerIndex, lastPlayedCard);
            }
        } 
        else if (choice == 2) 
        {
            cout << "Player " << (playerIndex + 1) << " passes their turn.\n\n";
            activePlayers[playerIndex] = false;
            return false;
        } 
        else 
        {
            cout << "Invalid card index, try again" << std::endl;
            std::cin >> choice;
        }
    }
    
    // recursively call function 
    return PlayerTurn(playerIndex, lastPlayedCard);
}

bool Deck::isValidPlay(int card, AVLTree<int>& hand, AVLTree<int>& currentRoundCards) 
{
    // validate that the card exists in the players hand
    if (!hand.search(card))
    {
        return false;
    }

    // declare a new value that finds the last card played
    // if no cards have been played, make the last card 0 so any card is greater than it
    // else, get the last value of the card played which should be the max value    
    int lastCard = (currentRoundCards.size() == 0) ? 0 : currentRoundCards.maxValue();
    
    return card > lastCard;
}

Card* Deck::FindCardByIndex(AVLNode<int>* node, int targetIndex, int& currentIndex) 
{
    if (!node)
    {
        return nullptr;
    }

    // traverse the left subtree
    Card* leftResult = FindCardByIndex(node->left, targetIndex, currentIndex);
    if (leftResult) 
    {
        return leftResult;
    }
    // process the current node
    if (currentIndex == targetIndex) 
    {
        return arrCards[node->key]; // map key to card in deck
    }
    currentIndex++;

    // traverse the right subtree through recursion
    return FindCardByIndex(node->right, targetIndex, currentIndex);
}

Card* Deck::GetCardFromIndex(AVLTree<int>& hand, int index) 
{
    int currentIndex = 1; 
    return FindCardByIndex(hand.getRoot(), index, currentIndex);
}

void Deck::ResetPlayers()
{
    // makes all the players active again
    for (int i = 0; i < 4; i++)
    {
        activePlayers[i] = true;
    }
    
    playedCount = 0; // clear the played cards array
    
    for (int i = 0; i < 52; i++) 
    {
        // makes all the values in the pointer null (resets them)
        playedCards[i] = nullptr;
    }
}
    
void Deck::Menu(int choice, int input)
{
    std::list<int> hand;
    
    do
    {
        cout << "Welcome to Tiến lên (Thirteen)! \n";
        cout << "If this is your first time playing, I recommend setting up a profile! \n\n";
        cout << "1. Play Game \n";
        cout << "2. Make/View Profile \n";
        cout << "3. How to play/instructions \n";
        cout << "4. Quit \n";  
    
        std::cin >> choice;

        switch (choice)
        {
            case 1:
                GameLoop();
                break;
            case 2:
                cout << "Profile setup/viewing selected.\n";
                cout << "Sorry this part is not yet properly set up\n\n";
                break;
            case 3:
                Instructions();
                break;
            case 4:
                cout << "Exiting Game, Come back soon!\n";
                break;
            default:
                cout << "\nINVALID INPUT\n";
                cout << "Choose an input between 1-4: ";
                break;
        }
    }while (choice != 4); 
}

//using cout for every time there is a new line for readability purposes in the code
void Deck::Instructions()
{
    cout << "Setup: \n"
            "The rules of the game are as follows, deal 4 players 13 cards each from a standard \n"
            "52-card deck. Deal and play is clockwise. For the first hand, the dealer is picked \n"
            "randomly; for subsequent hands, the loser of the previous hand deals. \n\n"
            
            "Cards rank (from high to low): 2 A K Q J 10 9 8 7 6 5 4 3. Within the numerical ranking, \n"
            "suits rank (from high to low): Hearts – Diamonds – Clubs – Spades. So for example \n"
            "(from higher to lower): 2♠ A♥ A♦ A♣ A♠ K♥. Thus 2♥ is the highest card and 3♠ the \n"
            "lowest. Players in turn discard single cards, or card combinations, to a central face-up \n"
            "pile. The object is to avoid being the last player to hold any cards. \n\n"
            
            "Starting: \n"
            "If the current game in the session is the first game played, the player with the 3♠ will \n"
            "start first. Since the deck of 52 cards is evenly split between 4 players, there is a \n"
            "guarantee 3♠ to start. Any subsequent games played in the same session after the first \n"
            "game will have the player who won the previous game start. This player may also play \n"
            "any card and combination of cards, but the first starting game must always start with a \n"
            "single 3♠. \n\n"
            
            "Valid cards or combinations that may be led are:\n"
            "   -A single card \n"
            "   -A pair of the same rank, as 4♠ 4♥ \n"
            "   -A triplet of the same rank, as 9♦ 9♣ 9♠ \n"
            "   -A quartet of the same rank, as A♥ A♦ A♣ A♠ \n"
            "   -A sequence of 3 or more cards, regardless of suit, as 9♣ 10♦ J♣ \n"
            "   -A double sequence of 3 or more pairs, regardless of suit, as 5♣ 5♠ 6♥ 6♦ 7♣ 7♦ \n\n"
            
            "A sequence of values cannot exceed past the highest value of 2, therefore you cannot \n"
            "chain past 2 with a 3. Example: K♣ A♦ 2♣ is valid but K♣ A♦ 2♣ 3♠ is not since it goes \n"
            "from the highest to the lowest value. \n\n"
            
            "Following: \n"
            "After the initial play, each player may either play or pass going in the order the cards \n"
            "were dealt out in with an initial starting point of whoever had the 3♠. To play, they must \n"
            "contribute a card or combination to the pile that matches the type (single, pair, etc.) of \n"
            "the one previously played, but beats it in rank. The highest-ranking card of each \n"
            "combination determines which beats which. There is no limit to what rank or suite can \n"
            "be played, but no combinations can be played unless certain conditions are met. \n\n"
            "Passing and playing continues around until there is a card or combination that no one \n"
            
            "can beat. Once a player has passed, they may not play again to this pile, but players \n"
            "may contribute more than 1 card or combination to the pile as long as they have not yet \n"
            "passed. When the winning card or combination has been determined, its player gathers \n"
            "the pile, sets it to the side, and leads any card or combination to a fresh pile. \n\n"
            
            "At the start of a fresh pile, the game repeats similarly to how a new game would. This \n"
            "can be thought of as a “round”. Each time there is a new fresh pile, a new round starts. \n"
            "With the start of this round, the winning player of the previous round may start with any \n"
            "combination they may desire. This will be further explored in the “Tips & Tricks” section. \n\n"
            
            "Bomb/Killing the pig: \n"
            "The exceptions to the strict rule of matching type and beating rank are called bombs \n"
            "and they may be played against 2’s: \n"
            "   -A single 2 may be beaten by any double sequence of 3+ pairs, as 4♣ 4♠ 5♥ 5♦ \n"
            "    6♣ 6♦ or a quartet, as 3♥ 3♦ 3♣ 3♠ \n"
            "   -A pair of 2s may be beaten by any double sequence of 4+ pairs, as 4♣ 4♠ 5♥ \n"
            "    5♦ 6♣ 6♦ 7♠ 7♥ or a quartet, as 3♥ 3♦ 3♣ 3♠ \n"
            "   -A triplet of 2s may be beaten by any double sequence of 5+ pairs, as 4♣ 4♠ \n"
            "    5♥ 5♦ 6♣ 6♦ 7♠ 7♥ 8♦ 8♣ \n"
            "Note: The suite of the cards do not matter, just the sequence. \n\n"
            
            "Round Finish: \n"
            "As players play their last cards, they drop out of play. If the leader to a new pile has no \n"
            "cards remaining, the lead passes to the next active player to the left. The game ends \n"
            "when only one player is left with any cards. That player is the loser. In a gambling game \n"
            "the loser pays each other player a fixed stake; in a drinking game, they buy the next \n"
            "round; in a friendly game, they shuffle the deck for the next match \n\n"
            
            "If the game is to be played with multiple games in one session, players can be \n"
            "appointed points that increase by 1 based on finishing position. For example, a player \n"
            "who finishes last place gets 0 points while a player who gets first will get 3 points, \n"
            "increasing by 1 per position. This applies in standard play of 4 players, but additional \n"
            "points can be earned throughout the game with the use of the “bomb”. For each 2 that is \n"
            "beaten, a point is taken from the player and given to the player who used the “bomb”. \n\n"
            
            "Conditions: \n"
            "There are a few conditions that can make a player automatically win in the game. \n"
            "Although there are a few variations of the game, the variation we will be basing this \n"
            "upon is a mix of America and Vietnamese culture. The following implementations are \n"
            "included: \n"
            "   -Automatically win if you have a combination streak of 12 cards or above \n"
            "   -Automatically win if you have every 2 in the deck \n"
            "   -Automatically win if you have all of the same suite in your original 13 card hand \n"
            "   -If a player holds onto a 2 card and proceed to lose (being the last player to get rid \n"
            "    of all their cards), they will lose points depending on how many 2’s they held onto \n"
            "   -If you’re using a “bomb” on another player, a different player can jump in whether \n"
            "    or not they have passed their turn. They can beat your “bomb” with a better \n"
            "    version of theirs as long as the sequence is higher or of greater suite value. \n\n";
}