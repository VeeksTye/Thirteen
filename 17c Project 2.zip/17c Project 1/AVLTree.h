/* 
 * File:   AVLTree.h
 * Author: Tyeson Nguyen
 * Date:   11/27/2024
 */

#ifndef AVLTREE_H
#define AVLTREE_H

#include "AVLNode.h"
#include <algorithm>
#include <iostream>
#include <functional>

using std::cout;

template <typename T> class AVLTree
{
private:
    // a pointer to the root of the tree
    AVLNode<T>* root;
    
    int height(AVLNode<T>* node);
    int balanceFactor(AVLNode<T>* node);
    AVLNode<T>* leftRotate(AVLNode<T>* x);
    AVLNode<T>* rightRotate(AVLNode<T>* y);
    AVLNode<T>* insert(AVLNode<T>* node, T key);
    AVLNode<T>* minValueNode(AVLNode<T>* node);
    AVLNode<T>* deleteNode(AVLNode<T>* root, T key);
    void inOrder(AVLNode<T>* root);
    bool search(AVLNode<T>* root, T key);
    
public:
    AVLTree();
    void insert(T key);
    void remove(T key);
    bool search(T key);
    void printInOrder();
    int size(AVLNode<T>* node);
    int size();
    T maxValue();
    AVLNode<T>* getRoot();
};

template <typename T>
int AVLTree<T>::height(AVLNode<T>* node) 
{
    if (node == nullptr) 
    {
        return 0;
    }
    return node->height;
}
// gets a balance factor of a node
template <typename T>
int AVLTree<T>::balanceFactor(AVLNode<T>* node) 
{
    if (node == nullptr) 
    {
        return 0;
    }

    return height(node->left) - height(node->right);
}
// left shifts the tree
template <typename T>
AVLNode<T>* AVLTree<T>::leftRotate(AVLNode<T>* x) 
{
    AVLNode<T>* y = x->right;
    AVLNode<T>* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = std::max(height(x->left), height(x->right)) + 1;
    y->height = std::max(height(y->left), height(y->right)) + 1;

    // return the new root
    return y;
}
// right rotation
template <typename T>
AVLNode<T>* AVLTree<T>::rightRotate(AVLNode<T>* y) 
{
    AVLNode<T>* x = y->left;
    AVLNode<T>* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = std::max(height(y->left), height(y->right)) + 1;
    x->height = std::max(height(x->left), height(x->right)) + 1;

    return x;
}
template <typename T>
AVLNode<T>* AVLTree<T>::insert(AVLNode<T>* node, T key) 
{
    // perform a BST insertion
    if (node == nullptr) 
    {
        return new AVLNode<T>(key);
    }
    if (key < node->key) 
    {
        node->left = insert(node->left, key);
    } 
    else if (key > node->key) 
    {
        node->right = insert(node->right, key);
    } 
    else 
    {
        return node;
    }

    // updates the height of the ancestor code
    node->height = 1 + std::max(height(node->left), height(node->right));

    // get the balance factor of the ancestor code
    int balance = balanceFactor(node);

    // if the node is unbalanced, we can do left/right shifts to balance out the node

    // LL Rotation (left shift left)
    if (balance > 1 && key < node->left->key) 
    {
        return rightRotate(node);
    }

    // RR Rotation (right shift right)
    if (balance < -1 && key > node ->right->key) 
    {
        return leftRotate(node);
    }

    // LR Rotation (left shift right)
    if (balance > 1 && key > node->left->key) 
    {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // RL Rotation (right shift left)
    if (balance < -1 && key < node->right->key)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}
// function that finds the node with the minimum key value
template <typename T> 
AVLNode<T>* AVLTree<T>::minValueNode(AVLNode<T>* node) 
{
    AVLNode<T>* current = node;
    
    while (current->left != nullptr) 
    {
        current = current->left;
    }
    
    return current;
}
//function that deletes from a the subtree root
template <typename T>
AVLNode<T>* AVLTree<T>::deleteNode(AVLNode<T>* root, T key) 
{
    // BST standard delete
    if (root == nullptr) 
    {
        return root;
    }

    if (key < root->key) 
    {
        root->left = deleteNode(root->left, key);
    } 
    else if (key > root->key) 
    {
        root->right = deleteNode(root->right, key);
    } 
    else 
    {
        if ((root->left == nullptr) || (root->right == nullptr)) 
        {
            AVLNode<T>* temp = root->left ? root->left : root->right;
            if (temp == nullptr) 
            {
                temp = root;
                root = nullptr;
            } 
            else 
            {
                *root = *temp;
            }
            delete temp;
        }
        else 
        {
            AVLNode<T>* temp = minValueNode(root->right);
            root->key = temp->key;
            root->right = deleteNode(root->right, temp->key);
        }
    }
    if (root == nullptr) 
    {
        return root;
    }

    // update the height of the current node
    root ->height = 1 + std::max(height(root->left), height(root->right));

    // gets the balance factor for the node
    int balance = balanceFactor(root);

    // same thing as before for LL or RR shifting

    // LL Rotation (left shift left)
    if (balance > 1 && balanceFactor(root->left) >= 0) 
    {
        return rightRotate(root);
    }

    // LR rotation (left shift right)
    if (balance > 1 && balanceFactor(root->left) < 0) 
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    // RR rotation (right shift right)
    if (balance < -1 && balanceFactor(root->right) <= 0) 
    {
        return leftRotate(root);
    }

    // RL rotation (right shift left)
    if (balance < -1 && balanceFactor(root->right) > 0) 
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}
// performs in order transversal for the tree
template <typename T>
void AVLTree<T>::inOrder(AVLNode<T>* root) 
{
    if (root != nullptr) {
        inOrder(root->left);
        cout << root->key << " ";
        inOrder(root->right);
    }
}
// function searches through the subtree roots for a key
template <typename T>
bool AVLTree<T>::search(AVLNode<T>* root, T key) 
{
    if (root == nullptr) 
    {
        return false;
    }

    if (root->key == key) 
    {
        return true;
    }

    if (key < root->key) 
    {
        return search(root->left, key);
    }

    return search(root->right, key);
}
template <typename T>
AVLTree<T>::AVLTree() : root(nullptr) { }
template <typename T>
void AVLTree<T>::insert(T key) 
{
    root = insert(root, key);
}
template <typename T>
void AVLTree<T>::remove(T key) 
{
    root = deleteNode(root, key);
}
template <typename T>
bool AVLTree<T>::search(T key) 
{
    return search(root, key);
}
template <typename T>
void AVLTree<T>::printInOrder() 
{
    inOrder(root);
    cout << std::endl;
}
template <typename T>
int AVLTree<T>::size(AVLNode<T>* node) 
{
    // if the tree is empty, return 0
    if (node == nullptr)
    {
        return 0;
    }
    // returns every node from the left and right sides of the trees together
    return 1 + size(node->left) + size(node->right);
}
template <typename T>
int AVLTree<T>::size() 
{
    return size(root);
}

// to find the max value in the tree
template <typename T>
T AVLTree<T>::maxValue() 
{
    if (!root) 
    {
        throw std::runtime_error("Tree is empty");
    }

    AVLNode<T>* current = root;
    while (current->right) 
    {
        current = current->right;
    }
    return current->key;
}

template <typename T>
AVLNode<T>* AVLTree<T>::getRoot()
{
    return root;
}
#endif /* AVLTREE_H */

