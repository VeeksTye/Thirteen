/* 
 * File:   AVLNode.h
 * Author: Tyeson Nguyen
 * Date:   11/27/2024
 */

#ifndef AVLNODE_H
#define AVLNODE_H

template <typename T> class AVLNode
{
public:
    // what each variable does:
    // T key: is used to store a value inside the node
    // left/right: points to the left and right nodes
    // height: for the size of the tree
    
    T key;
    AVLNode* left;
    AVLNode* right;
    int height;
    
    // constructor to set the value of the node into the tree
    AVLNode(T k):key(k), left(nullptr), right(nullptr), height(1) { }
};


#endif /* AVLNODE_H */

    