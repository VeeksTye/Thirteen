#ifndef DECK_H
#define DECK_H

//include Card.h to make Deck aware of the Card class
//include Player.h to set player hand from deck class
#include "Card.h"
#include "Player.h"
#include "AVLTree.h"
#include <list>
#include <queue>
#include <stack>

class Deck
{
private:
    Card* arrCards[52];
    Card* playedCards[52];              // create another card pointer similar to arrCards[52], but keeps track of the current played cards in a game
    Player player[4];
    AVLTree<int> cards;                 // can be used to store the cards
    AVLTree<int> currentRoundCards;     // keeps track of the current round cards (reset start of every round)
    AVLTree<int> playerHand[4];         // can store player hands
    
    std::list<int> round;
    std::stack<int> players;
    std::queue<int> turn;
    
    int currentPlayer, playedCount;
    bool activePlayers[4] = {true, true, true, true};
    
public:
    //default constructor
    Deck();
    ~Deck(); //destructor
    
    void SetUpCards();
    //void PrintAll();      Can be used later for debugging
    void SetPlayerHand();
    void PrintHandHelper(AVLNode<int>*, int&);
    void PrintHand(AVLTree<int>&);
    void Menu(int, int);
    void Instructions();
    void PrintRound();
    void PlayCard(int, Card*);
    void RemoveCard(AVLTree<int>&, int);
    void AddPlayedCard(Card*);

    void GameLoop();
    void AdvanceTurn();
    void PassTurn();
    void InitializeTurnOrder(int);
    
    bool isValidPlay(int, AVLTree<int>&, AVLTree<int>&);
    bool FindWinner();
    bool PlayerTurn(int, int&);
    void ResetPlayers();
    int DealCards();
    
    Card* GetCardFromIndex(AVLTree<int>&, int);
    Card* FindCardByIndex(AVLNode<int>*, int, int&);
};

#endif /* DECK_H */